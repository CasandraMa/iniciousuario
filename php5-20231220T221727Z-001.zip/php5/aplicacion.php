<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="index.css">
    <title>Aplicacion</title>
</head>
<body>
     <!--This is a bar menu for the all pages except index and info for guest -->
<div id="nav-tabs">
        <nav>
            <ul>
                <li><a href="aplicacion.php" target="_self">Visitas del usuario</a></li>
                <li><a href="preferencias.php" target="_self">Preferencias</a></li>
                <li><a href="informacion.php" target="_self">informacion</a></li>
                <form id='vaciar' action='<?php echo $_SERVER['PHP_SELF'];?>' method='post'>
                    <input type ='submit' class="button" value='Cerrar sesión' name='cerrar'/>
                </form>
       
            </ul>
        </nav>  
  
    </div>
    <h4>Aplicación realizada por Casandra Marín Angulo</h4>
    <div id="nav-app">
        <nav>
            <ul>
                <li><a href="insert.php" target="_self">Insertar Usuario</a></li>
                <li><a href="modify.php" target="_self">Modificar Usuario</a></li>
                <li><a href="delete.php" target="_self">Eliminar Usuario</a></li>
            </ul>
        </nav>  
    <div class="apli">
    <!-- include the page of functions and add the functions of page need. -->
    <?php 
    include("funciones.php");
        prefecolor();
       
     
        if (!isset($_SESSION['visita'])){
            echo "<h1>Bienvenido. Esta es tu primera visita ".$_SESSION['usuario']."</h1><br/>";
            date_default_timezone_set('Europe/Madrid');
            echo "<p>Usuario: ".$_SESSION['usuario']."</p>";
            echo "<p>Fecha: ".date("d/m/y")."</p>";
            echo "<p>Hora: ".date("H:i:s")."</p>";

        }
        else{
            date_default_timezone_set('Europe/Madrid');
                echo "<p>Usuario: ".$_SESSION['usuario']."</p>";
                echo "<p>Fecha: ".date("d/m/y")."</p>";
                echo "<p>Hora: ".date("H:i:s")."</p>";
        }
        if(isset($_SESSION['usuario'])){
            comprobarUsuario($_SESSION['usuario'],$_SESSION['pass']);
        }
        else{
            header('Location: index.php');
        }
    
        cerrasesion();
   
    ?>
    </div>

    
</body>
</html>