<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="index.css">
    <title>Aplicacion</title>
</head>
<body>
     <!--This is a bar menu for the all pages except index and info for guest -->
<div id="nav-tabs">
        <nav>
            <ul>
                <li><a href="aplicacion.php" target="_self">Visitas del usuario</a></li>
                <li><a href="preferencias.php" target="_self">Preferencias</a></li>
                <li><a href="informacion.php" target="_self">informacion</a></li>
                <form id='vaciar' action='<?php echo $_SERVER['PHP_SELF'];?>' method='post'>
                    <input type ='submit' class="button" value='Cerrar sesión' name='cerrar'/>
                </form>
       
            </ul>
        </nav>  
  
    </div>
    <h4>Aplicación realizada por Casandra Marín Angulo</h4>
    <div id="nav-app">
        <nav>
            <ul>
                <li><a href="insert.php" target="_self">Insertar Usuario</a></li>
                <li><a href="modify.php" target="_self">Modificar Usuario</a></li>
                <li><a href="delete.php" target="_self">Eliminar Usuario</a></li>
            </ul>
        </nav>  
    <div class="apli">

    
    <!-- Container where I store the information about the different options in each section. -->
    <nav class= "contenedordos">

        <!-- Form to modify a commercial from its code -->
        <nav id="modificarusuario">
            <h3>MODIFICAR UN USUARIO:</h3>
            <form method="POST" action="<?php echo $_SERVER['PHP_SELF']; ?>" target="_self">
                <div class="mb-3">
                <span> USUARIO: </span>
                    <select class="form-select" name="id">
                    <?php
                        if(isset($_POST['id'])) {
                            $id = $_POST['id'];

                        }
                        @$ven = new mysqli("localhost", "root", "", "tarea4");
                        $error = $ven->connect_errno;
                        if ($error == null) {
                        $resultado = $ven-> query('SELECT id,usuario FROM usuarios');
                            if($resultado){
                                $desple = $resultado->fetch_assoc();
                                while ($desple != null){
                                    echo"<option value='${desple['id']}'";
                                    if (isset($id) && $id == $desple['id'] && $nomusu = $desple['usuario']) 
                                        echo "selected = 'true'";
                                        echo ">${desple['id']}: ${desple['usuario']}</option>";
                                        $desple = $resultado->fetch_assoc();        
                                }
                                
                                $resultado->close(); 
                            }
                        }
                        else{
                            $ven ->connect_error;
                            }
                    
                    ?>
                    </select></br>
                    <input type ='submit' class="button" value='Eliminar Usuario' name='eliminar'/>
            </form>
            
        </nav>

        <?php
include("funciones.php");
    prefecolor();


        if(isset($_SESSION['usuario'])){
            comprobarUsuario($_SESSION['usuario'],$_SESSION['pass']);
        }
        else{
            header('Location: index.php');
        }

        cerrasesion();

// When you have selected one user
    if ($_SERVER["REQUEST_METHOD"] === "POST") {
        
        if (isset($_POST['eliminar'])) { // when modify a user
            $id = $_POST["id"];
        
            if ($id != null){
                eliminarusuario($id);
            }
            else{
                echo " Existe un campo vacio, porfavor, introduzca todos los datos" ;
            }
        
        }
        
    }

        ?>

    </body>
</html>