<?php

class Usuario {
    protected $id;
    protected $nombre;
    protected $pwd;
    protected $correo;
    
    public function getid() {return $this->id; }
    public function getnombre() {return $this->nombre; }
    public function getpass() {return $this->pwd; }
    public function getcorreo() {return $this->correo; }

    public function setnombre($nombre) {$this->nombre = $nombre; }
    public function setpass($pwd) {
        $pwd = password_hash("$pwd", PASSWORD_DEFAULT);
        $this->pwd = $pwd; }
    public function setcorreo($correo) {$this->correo = $correo; }


    public function __construct($nombre,$pwd,$correo) {
        $this->nombre = $nombre; 
        $this->pwd = $pwd; 
        $this->correo = $correo; 
    }

    public function toString(){
        return "Usuario: [ id='".$this->getid()."' , nombre='".$this->getnombre()."' ,contraseña=.'".$this->getpass()."]";
    }

   
}

?>