<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="index.css">
    <title>Información</title>
</head>
<body>

    <!-- include the page of functions and add the functions of page need. -->
<?php
include("funciones.php");
    barrainfo();
    cerrasesion();
    prefecolor();

        //Collect the information sent by post onclick button.
    if ($_SERVER["REQUEST_METHOD"] === "POST") {
        if(isset($_POST['volver'])){
           if($_SESSION['usuario'] != null){
                header("Location:aplicacion.php");
            }
            else{
                header("Location:index.php");
            }
            
        }
    }   
?>

<div class="info">
    <h1>Información</h1>
    <p> Esta página web es un ejercicio realizado para la asignatura de " Desarrollo en entorno sevidor ", esta en concreto es para el tema 4, 
        dirigido sobre todo al tema de inicio de sesión seguro,es por ello, que esta pagína realiza la función de inicio de sesión,
        que si el usuario es correcto podra acceder al documento " aplicación.php ", el apartado de preferencias y cerrar sesión, tambien podra acceder a " información.php ",
        En el caso de entrar como invitado solo podra acceder a  " información.php ". </p>
        <!-- button go back to the beginning -->
        <form id='volver'  method='post'>
            <input type ='submit' class='button' value='Volver al inicio' name='volver'/> 
        </form>
</div>
</body>
</html>