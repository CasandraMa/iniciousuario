<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="index.css">
    <title>Aplicacion</title>
</head>
<body>
     <!--This is a bar menu for the all pages except index and info for guest -->
<div id="nav-tabs">
        <nav>
            <ul>
                <li><a href="aplicacion.php" target="_self">Visitas del usuario</a></li>
                <li><a href="preferencias.php" target="_self">Preferencias</a></li>
                <li><a href="informacion.php" target="_self">informacion</a></li>
                <form id='vaciar' action='<?php echo $_SERVER['PHP_SELF'];?>' method='post'>
                    <input type ='submit' class="button" value='Cerrar sesión' name='cerrar'/>
                </form>
       
            </ul>
        </nav>  
  
    </div>
    <h4>Aplicación realizada por Casandra Marín Angulo</h4>
    <div id="nav-app">
        <nav>
            <ul>
                <li><a href="insert.php" target="_self">Insertar Usuario</a></li>
                <li><a href="modify.php" target="_self">Modificar Usuario</a></li>
                <li><a href="delete.php" target="_self">Eliminar Usuario</a></li>
            </ul>
        </nav>  
    <div class="apli">
    <!-- include the page of functions and add the functions of page need. -->
  

    <!-- Form to insert a new commercial -->
    <div id="insertuser">
        <h3>INSERTAR UN NUEVO USUARIO:</h3>
        <form method="POST" action="<?php echo $_SERVER['PHP_SELF']; ?>" target="_self">
            <div class="mb-3">
                <label for="usuario" class="form-label">Nombre del usuario</label>
                <input type="text" class="form-control" id="usuario"  name="usuario">
                <label for="contra" class="form-label">Contraseña</label>
                <input type="password" class="form-control" id="contra" name="contra">
                <label for="correo" class="form-label">Correo Electronico</label>
                <input type="text" class="form-control" id="correo"  name="correo">
                <input type ='submit' class="button" value='Añadir Usuario' name='aniadiruser'/>
        </form>
</div>
        
   
<?php
include("funciones.php");
    prefecolor();


        if(isset($_SESSION['usuario'])){
            comprobarUsuario($_SESSION['usuario'],$_SESSION['pass']);
        }
        else{
            header('Location: index.php');
        }

        cerrasesion();
// When you have selected one of the buttons you will go to one selection or another
    if ($_SERVER["REQUEST_METHOD"] === "POST") {
        
        if (isset($_POST['aniadiruser'])) {  // When insert a new user
            $nombre = $_POST["usuario"];
            $contra = $_POST["contra"];
            $correo = $_POST["correo"];
            if ($nombre != null && $contra != null && $correo != null){
            insertarusuario($nombre, $contra, $correo);
            }
            else{
            echo " Existe un campo vacio, porfavor, introduzca todos los datos" ;
            }
        
        }
        
    }







?>






    

</body>
</html>