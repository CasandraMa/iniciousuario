<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="index.css">
    <title>Aplicación</title>
   
</head>
<body>
     <!--This is a bar menu for the all pages except index and info for guest -->
    <div id="nav-tabs">
        <nav>
            <ul>
                <li><a href="aplicacion.php" target="_self">Visitas del usuario</a></li>
                <li><a href="preferencias.php" target="_self">Preferencias</a></li>
                <li><a href="informacion.php" target="_self">informacion</a></li>
                <form id='vaciar' action='<?php echo $_SERVER['PHP_SELF'];?>' method='post'>
                    <input type ='submit' class="button" value='Cerrar sesión' name='cerrar'/>
                </form>
       
            </ul>
        </nav>  

    </div>
    <!-- This page change the preferences for background color, take the value on input and post the information a function -->
    <div class="preferencias">
    
    <form method="POST" action="<?php echo $_SERVER['PHP_SELF']; ?>" target="_self">

        <p>Color principal del perfil: <input type="color" id="colorpicker" name="color"></p>
        <input type ='submit' class="button" value='Cambiar fondo' name='cambiar'/>
        <input type ='submit' class="button" value='Restablecer preferencias' name='restablecer'/>


    </form>

   
    <!-- include the page of functions and add the functions of page need. -->
    <?php
    include("funciones.php");
    cerrasesion();
    prefeColor();
    
    if(isset($_SESSION['usuario'])){
        comprobarUsuario($_SESSION['usuario'],$_SESSION['pass']);
    }
    else{
        header('Location: index.php');
    }

   
  
   
    //Collect the information sent by post and depending on the button, choose the option to perform.
    if ($_SERVER["REQUEST_METHOD"] === "POST") {
        if(isset($_POST['cambiar'])){
            $color=$_POST['color'];
            $_SESSION['color']= $color;
            header("Location:preferencias.php");
        }
        elseif (isset($_POST['restablecer'])) {
            restablecer();
            header("Location:preferencias.php");
        }       
    }
    ?>
    </div>
</body>
</html>