<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" >
    <link rel="stylesheet" href="index.css">
    <title>Autentificación de Usuario</title>
</head>
<body>
    <style>
        body{
            background-image:url("52045.jpg");
            background-position: center; 
            background-repeat: no-repeat; 
            background-size: cover; 
        }
     </style>

    <div class="inicio">
        
        <form method="POST" action="<?php echo $_SERVER['PHP_SELF']; ?>" target="_self">
        <div class="mb-3">
            <h3>LOGIN</h3>
            <div class="etiquetas">
                <label for="user" class="form-label">Nombre de Usuario</label></br>
                <input type="text" class="form-control" id="user"  name="user"></br>
                <label for="pass" class="form-label">Contraseña</label></br>
                <input type="password" class="form-control" id="pass" name="pass"></br>
            <div>
            <div class="botoninicio">
                <input type ='submit' class="button" value='Iniciar sesión' name='iniciosesion'/>
                <input type ='submit' class="button" value='Invitado' name='invitado'/>
            </div>
            
        <form>

    

    <?php
    require_once("funciones.php");
    prefecolor();


    // When you have selected one of the buttons you will go to one selection or another
        if ($_SERVER["REQUEST_METHOD"] === "POST") {
            if(isset($_POST['iniciosesion'])){
                $usuario=$_POST['user'];
                $contrasena=$_POST['pass'];
            
                if($usuario!= null && $contrasena!=null){
                    comprobarUsuario($usuario,$contrasena);
                }
                
            }
            elseif(isset($_POST['invitado'])) {
                header("Location:informacion.php");
            }
        }   
         
    ?>
    </div>
    
</body>
</html>