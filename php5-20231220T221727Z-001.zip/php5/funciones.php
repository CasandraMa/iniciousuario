<?php
require_once('usuario.php');

// Iniciate the sesion in this page for use in all pages 
session_start();

// Check the data base conect
function conectarBase(){
    @$sql = new mysqli("localhost", "root", "", "tarea4");
    $error = $sql->connect_errno;
    if($error){
        echo "<p>'Error al conectarse a la base de datos'</p>";
    }
    else{
        return $sql;
    }
}

// Check if the user and pass is on data base
function comprobarUsuario($usuario, $pass){

    if (!isset($_SESSION['usuario'])){
        $_SESSION['usuario']=null;
    }
        
    if ($_SESSION['usuario']==null){ //if (count($_SESSION['usuario'])==0){
        // Conect with data base
        try {
            $usuarioverificado = obtieneUsuario($usuario);
            $comprobar = false;
            }catch (Exception $ex)
                {
                    exit;
                }
             

        if($usuarioverificado != null){
            if(password_verify($pass,$usuarioverificado->getpass())){
                $_SESSION['usuario']=$usuarioverificado->getnombre();
                $_SESSION['pass']=$usuarioverificado->getpass();
                $comprobar = true;
               
                echo '</br><p>Usuario Autentificado</p>';
                header("Location:aplicacion.php");  // Redirect a the page aplication
                return $comprobar;
           }
            else {
                echo '</br></br><p>Usuario o contraseña incorrectos</p>';
                $comprobar= false;
                return $comprobar;
            }
        }
       
      
    }
}

// Log out and delete the user, background, and visits.
function cerrasesion(){
    if (isset($_POST['cerrar'])){
        unset($_SESSION['visita']);
        unset($_SESSION['usuario']);
        unset($_SESSION['color']);
        header("Location:index.php");
    }
    else{
        $_SESSION['visita']=time(); //if change of page or reload this page and keep the time of visit
    }
     
}

function mostrarsesion(){
      echo "<p>".$_SESSION['usuario'] ."(".date("H:i:s").")</p>";
}

// Only appears the bar menu in case of the user is Log in
function barrainfo(){
    if(isset($_SESSION['usuario'])){   
        echo "<div id='nav-tabs'>";
            echo "<nav>";
                echo "<ul>";
                    echo " <li><a href='aplicacion.php' target='_self'>Visitas del usuario</a></li>";
                    echo "<li><a href='preferencias.php' target='_self'>Preferencias</a></li>";
                    echo "<li><a href='informacion.php' target='_self'>informacion</a></li>";
                    echo "<form id='vaciar' action='".$_SERVER['PHP_SELF']."' method='post'>";
                        echo "<input type ='submit' class='button' value='Cerrar sesión' name='cerrar'/>";
                    echo "</form>";
            
                echo "</ul>";
            echo "</nav>";
    
        echo "</div>";
    }
}

// Change the color of background, for default the color is white.
function prefecolor(){
    if(!isset($_SESSION['color'])){
        $_SESSION['color']="#FFFFFF";
    }
    else{
        $color=$_SESSION['color'];
      
    }
    $color= $_SESSION['color'];
    echo "<style>
    body
    {
        margin:auto;
        font-family: 'Arvo', serif;
        background-color:$color;
    } 
   
    </style>";
}

// Function to delete the change of background
function restablecer(){
    unset($_SESSION['color']); 
}

//////// NEWS FUNCTIONS


function obtieneUsuario($user) {
    $sql = conectarBase();
    $resultado = $sql->query("SELECT usuario, pwd, email FROM usuarios WHERE usuario='$user'");
   
    if(isset($resultado)) {
        $row = $resultado->fetch_assoc();
        $usuario = new Usuario($row['usuario'],$row['pwd'],$row['email']);
    }
    else{
        $usuario = null;
    }
    $resultado->close();
    return $usuario;    
}



function insertarusuario($name, $pass, $mail){
    if(isset($_SESSION['usuario'])){ 
        $sql = conectarBase();
        $resultado = $sql->query("SELECT * FROM usuarios WHERE usuario='$name'");
        
        if($resultado->num_rows > 0 ) {
            $mensaje = "<br><p> Ya existe ese Usuario</p>";
          
        }
        else{
            $pwd = password_hash("$pass", PASSWORD_DEFAULT);
            $sql= conectarBase();
            $sql->query("INSERT INTO `usuarios`(`usuario`, `pwd`, `email`) VALUES ('$name','$pwd','$mail')");
            $mensaje = "<br><p>Se ha agregado correctamente</p>";
        }        
        
    }
    

    echo $mensaje;
}

function modificarusuario($id,$nombre, $pass, $email){
    if(isset($_SESSION['usuario'])){ 
        $sql = conectarBase();
        $resultado = $sql->query("SELECT * FROM usuarios WHERE id='$id'");
        
        if($resultado->num_rows > 0 ) {
            $pwd = password_hash("$pass", PASSWORD_DEFAULT);
            $sql->query("UPDATE usuarios SET usuario='$nombre',pwd='$pwd',email='$email' WHERE id = '$id'");
            $mensaje = "<br><p>Se ha agregado correctamente</p>";
        
          
        }
        else{
            $mensaje = "<br><p>No se ha podido agregar correctamente</p>";
        }        
        
    }
    

    echo $mensaje;
}

function eliminarusuario($id){
    $sql = conectarBase();
    $resultado = $sql->query("SELECT * FROM usuarios WHERE id='$id'");

    if ($resultado->num_rows > 0) {
        $sql->query("DELETE FROM usuarios WHERE id = '$id'");
        $mensaje = "<br><p>Se ha eliminado correctamente</p>";
    } 
    else {
        $mensaje = "<br><p>No se ha podido eliminar</p>";
    }


    echo $mensaje;
}



?>